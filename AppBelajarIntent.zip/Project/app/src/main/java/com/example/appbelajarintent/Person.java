package com.example.appbelajarintent;

class Person {
    String Mail;
    String  Location;
    int age;
}
